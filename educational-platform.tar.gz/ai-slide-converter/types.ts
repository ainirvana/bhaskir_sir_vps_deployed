
export interface Slide {
  title: string;
  content: string[]; // Array of strings, each being a bullet point or paragraph
}

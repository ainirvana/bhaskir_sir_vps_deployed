export { default } from './enhanced-page';
